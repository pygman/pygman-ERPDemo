package @package_addr@.@small@.dao.dao;

import @package_addr@.@small@.vo.@big@Model;
import cn.itcast.invoice.util.base.BaseDao;

public interface @big@Dao extends BaseDao<@big@Model>{

}
