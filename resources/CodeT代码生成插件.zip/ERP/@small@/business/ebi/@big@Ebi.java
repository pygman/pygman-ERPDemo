package @package_addr@.@small@.business.ebi;

import org.springframework.transaction.annotation.Transactional;

import @package_addr@.@small@.vo.@big@Model;
import cn.itcast.invoice.util.base.BaseEbi;
@Transactional
public interface @big@Ebi extends BaseEbi<@big@Model>{

}
