package @package_addr@.@small@.vo;

import cn.itcast.invoice.util.base.BaseQueryModel;

public class @big@QueryModel extends @big@Model implements BaseQueryModel{
	//TODO 添加查询范围字段 
}
