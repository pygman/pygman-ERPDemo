package @package_addr@.@small@.vo;

import java.util.HashMap;
import java.util.Map;
import cn.itcast.invoice.util.format.FormatUtil;

public class @big@Model {

	@model_properties@

}
